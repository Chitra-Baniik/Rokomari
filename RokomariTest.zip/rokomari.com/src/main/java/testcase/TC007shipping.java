package testcase;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TC007shipping {

	static WebDriver driver = null;

	public TC007shipping(WebDriver driver) {
		TC007shipping.driver = driver;
	}

	By altphone = By.xpath(
			"//body/div[@id='shipping-payment']/div[1]/div[1]/div[1]/form[1]/div[1]/div[1]/div[2]/div[2]/div[1]/fieldset[2]/input[1]");

	public void Givealtphone() {
		driver.findElement(altphone).sendKeys("01977777777");
	}

	By city = By.xpath("//select[@id='js--city']");

	public void Givecity() {
		driver.findElement(city).click();
	}
	By area = By.xpath("//select[@id='js--area']");

	public void Givearea() {
		driver.findElement(area).click();
	}

	By adress = By.xpath(
			"//body/div[@id='shipping-payment']/div[1]/div[1]/div[1]/form[1]/div[1]/div[1]/div[2]/div[2]/fieldset[2]/textarea[1]");

	public void Giveaddress() throws InterruptedException {
		JavascriptExecutor jsd = (JavascriptExecutor) driver;
		WebElement d = driver.findElement(By.xpath("//select[@id='js--city']"));
		jsd.executeScript("arguments[0].scrollIntoView();", d);
		Thread.sleep(2000);
		driver.findElement(adress).sendKeys("9/A,55/G,Dhanmondi");
	}

}
