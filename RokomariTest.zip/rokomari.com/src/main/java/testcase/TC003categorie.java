package testcase;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TC003categorie {

	static WebDriver driver = null;
	public TC003categorie(WebDriver driver) {
		TC003categorie.driver = driver;
	}
	
	By Nobel = By.xpath("//body/div[5]/div[1]/div[1]/div[1]/section[1]/form[1]/div[2]/div[2]/ul[1]/li[1]/div[1]/label[1]");
	
	public void clickNobelButton() throws InterruptedException {
		JavascriptExecutor jsn = (JavascriptExecutor)driver;
		WebElement n=driver.findElement(By.xpath("//body/div[5]/div[1]/div[1]/div[2]/section[2]/div[1]/div[1]/div[1]"));
		jsn.executeScript("arguments[0].scrollIntoView();",n);
		Thread.sleep(4000);
		driver.findElement(Nobel).click();
	}
	
}
