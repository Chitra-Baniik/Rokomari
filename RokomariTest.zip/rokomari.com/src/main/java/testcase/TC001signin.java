package testcase;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TC001signin {

	WebDriver driver = null;

	public TC001signin(WebDriver driver) {
		this.driver = driver;
	}

	By signin = By.xpath("//a[contains(text(),'Sign in')]");
	By email = By.xpath("//input[@id='j_username']");
	By typepass = By.xpath("//input[@type='password']");
	By sign = By.xpath("//button[contains(text(),'Sign In')]");

	public void clicksignin() {
		driver.findElement(signin).click();
	}

	public void clicktypeemail() {
		driver.findElement(email).sendKeys("chitrabaniksr@gmail.com");
	}

	public void clicktypepass() {
		driver.findElement(typepass).sendKeys("016790210422");
	}

	public void clicksign() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor)driver;
		WebElement e=driver.findElement(By.xpath("//form[@id='loginForm']"));
		js.executeScript("arguments[0].scrollIntoView();",e);
		Thread.sleep(2000);
		driver.findElement(sign).click();
	}

}
