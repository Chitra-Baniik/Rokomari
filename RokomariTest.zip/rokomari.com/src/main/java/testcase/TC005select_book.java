package testcase;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class TC005select_book {
	
	static WebDriver driver = null;
	public TC005select_book(WebDriver driver) {
		TC005select_book.driver = driver;
	}
	
	By book = By.xpath("//body/div[5]/div[1]/div[1]/div[2]/section[2]/div[2]/div[1]/div[1]/div[1]/a[1]/div[1]/div[1]/button[1]");
	
	public void clickscroolButton() throws InterruptedException {
		JavascriptExecutor jsb = (JavascriptExecutor)driver;
		WebElement b=driver.findElement(By.xpath("//body/div[5]/div[1]/div[1]/div[2]/section[2]/div[2]/div[1]/div[2]/div[1]"));
		jsb.executeScript("arguments[0].scrollIntoView();",b);
		Thread.sleep(3000);
	}
	public void clickhoverbook() {
		Actions actionn=new Actions(driver);
		WebElement ele=driver.findElement(By.xpath("//body/div[5]/div[1]/div[1]/div[2]/section[2]/div[2]/div[1]/div[1]/div[1]"));
		actionn.moveToElement(ele).build().perform();
	}
	public void clickaddbutton() {
		driver.findElement(book).click();
	}
	
}
