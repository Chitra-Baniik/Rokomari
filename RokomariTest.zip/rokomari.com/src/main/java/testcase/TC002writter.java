package testcase;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;


public class TC002writter {

	static WebDriver driver = null;

	public TC002writter(WebDriver driver) {
		TC002writter.driver = driver;
	}

	public void clickwritter() {
		Actions action=new Actions(driver);
		WebElement element=driver.findElement(By.linkText("লেখক"));
		action.moveToElement(element).build().perform();
	}

	By hu = By.xpath("//a[contains(text(),'হুমায়ূন আহমেদ')]");

	public void clickhu() {
		driver.findElement(hu).click();
	}

}
