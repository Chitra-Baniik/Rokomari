package testcase;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TC004nextpage {
	
	static WebDriver driver = null;
	public TC004nextpage(WebDriver driver) {
		TC004nextpage.driver = driver;
	}
	By next = By.xpath("//a[contains(text(),'Next')]");
	
	
	public void clickNextButton() throws InterruptedException {
		JavascriptExecutor jsx = (JavascriptExecutor)driver;
		WebElement x=driver.findElement(By.xpath("//body/div[5]/div[1]/div[1]/div[2]/section[2]/div[2]/div[1]/div[58]/div[1]"));
		jsx.executeScript("arguments[0].scrollIntoView();",x);
		Thread.sleep(4000);
		driver.findElement(next).click();
	}
}
