package testcase;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TC006cart {
	
	static WebDriver driver = null;
	public TC006cart(WebDriver driver) {
		
		TC006cart.driver = driver;
	}
	By cart = By.xpath("//*[@id='cart-icon']");
	By placeorder =By.xpath("//a[@id='js-continue-to-shipping']");
	public void clickcarticon() {
		driver.findElement(cart).click();
	}
	
	public void clickscroolButton() throws InterruptedException {
		JavascriptExecutor jsb = (JavascriptExecutor)driver;
		WebElement b=driver.findElement(By.xpath("//body/div[@id='cart-page']/div[1]/div[1]/div[1]/div[2]/div[1]"));
		jsb.executeScript("arguments[0].scrollIntoView();",b);
		Thread.sleep(3000);
	}
	public void clickplaceorder() {
		driver.findElement(placeorder).click();
	}


}
