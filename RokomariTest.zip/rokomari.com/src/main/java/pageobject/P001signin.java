package pageobject;

import org.testng.annotations.Test;
import base.DriverSetup;
import testcase.TC001signin;
import testcase.TC002writter;
import testcase.TC003categorie;
import testcase.TC004nextpage;
import testcase.TC005select_book;
import testcase.TC006cart;
import testcase.TC007shipping;

public class P001signin extends DriverSetup {
	public static String baseurl = "https://www.rokomari.com/book";

	@Test
	public void tc1() throws InterruptedException {
		driver.get(baseurl);
		driver.manage().window().maximize();

		TC001signin learn = new TC001signin(driver);
		learn.clicksignin();
		Thread.sleep(3000);

		learn.clicktypeemail();
		Thread.sleep(2000);

		learn.clicktypepass();
		Thread.sleep(2000);

		learn.clicksign();
		Thread.sleep(2000);
	}

	@Test
	public void tc2() throws InterruptedException {
		TC002writter w = new TC002writter(driver);
		w.clickwritter();
		Thread.sleep(2000);
		w.clickhu();
		Thread.sleep(2000);
	}

	@Test
	public void tc3() throws InterruptedException {
		TC003categorie C = new TC003categorie(driver);
		C.clickNobelButton();
		Thread.sleep(3000);
	}

	@Test
	public void tc4() throws InterruptedException {
		TC004nextpage N = new TC004nextpage(driver);
		N.clickNextButton();
		Thread.sleep(3000);
	}

	@Test
	public void tc5() throws InterruptedException {
		TC005select_book A = new TC005select_book(driver);
		A.clickscroolButton();
		Thread.sleep(2000);
		A.clickhoverbook();
		Thread.sleep(3000);
		A.clickaddbutton();
		
		Thread.sleep(3000);
	}
	
	@Test
	public void tc6() throws InterruptedException {
		TC006cart Ac = new TC006cart(driver);
		Ac.clickcarticon();
		Thread.sleep(3000);
		Ac.clickscroolButton();
		Thread.sleep(3000);
		Ac.clickplaceorder();
		Thread.sleep(3000);
	}
	
	
	@Test
	public void tc7() throws InterruptedException {
		TC007shipping S = new TC007shipping(driver);
		S.Givealtphone();
		Thread.sleep(2000);
		S.Givecity();
		Thread.sleep(2000);
		S.Givearea();
		Thread.sleep(2000);
		S.Giveaddress();
		Thread.sleep(5000);
	}
}
